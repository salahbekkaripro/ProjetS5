"use client"

import {
  Activity,
  Award,
  Dumbbell,
  TrendingUp,
  Zap,
  Target,
  ChevronRight,
  Calendar,
  BarChart3,
  Flame,
  Trophy,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export function Dashboard() {
  const user = {
    firstName: "Alex",
    subscription: "Fit+",
    workoutsCount: 12,
    streak: 7,
    points: 2450,
    level: 8,
  }

  const kpis = [
    { label: "Points", value: "2,450", sub: "Niveau 8", icon: Zap, color: "from-primary to-orange-500" },
    { label: "Workouts 7j", value: "12", sub: "Volume 3,240", icon: Dumbbell, color: "from-secondary to-purple-500" },
    { label: "Streak", value: "7 j", sub: "Best 21 j", icon: Flame, color: "from-destructive to-orange-600" },
    { label: "Badges", value: "8", sub: "3 objectifs actifs", icon: Trophy, color: "from-accent to-green-500" },
  ]

  const recentWorkouts = [
    { title: "Upper Body Push", date: "Aujourd'hui", sets: 15, volume: 2840 },
    { title: "Legs & Core", date: "Hier", sets: 18, volume: 4250 },
    { title: "Pull Day", date: "Il y a 2 jours", sets: 14, volume: 2650 },
    { title: "Full Body", date: "Il y a 3 jours", sets: 20, volume: 3890 },
  ]

  const goals = [
    { title: "Bench Press 100kg", progress: 85, color: "bg-primary" },
    { title: "Deadlift 180kg", progress: 72, color: "bg-secondary" },
    { title: "50 workouts", progress: 64, color: "bg-accent" },
  ]

  const trends = [
    { exercise: "Bench Press", current: "95", predicted: "98" },
    { exercise: "Squat", current: "140", predicted: "145" },
    { exercise: "Deadlift", current: "165", predicted: "172" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-primary via-orange-500 to-accent bg-clip-text text-transparent animate-gradient">
                FitTrackr
              </h2>
              <div className="hidden md:flex items-center gap-6">
                <a
                  href="#"
                  className="text-sm font-semibold text-foreground hover:text-primary transition-colors relative group"
                >
                  Dashboard
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary scale-x-100 transition-transform" />
                </a>
                <a
                  href="#"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
                >
                  Workouts
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform" />
                </a>
                <a
                  href="#"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
                >
                  Programmes
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform" />
                </a>
                <a
                  href="#"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
                >
                  Objectifs
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform" />
                </a>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="hidden sm:flex font-semibold">
                Plan: {user.subscription}
              </Badge>
              <Button size="sm" className="gap-2 shadow-md hover:shadow-lg transition-all">
                <Activity className="h-4 w-4" />
                Chat IA
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <Card className="mb-6 overflow-hidden border-2 border-primary/20 shadow-xl relative">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10 animate-gradient bg-[length:200%_200%]" />
          <CardContent className="p-6 md:p-8 relative">
            <div className="grid md:grid-cols-5 gap-6">
              <div className="md:col-span-3 space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-primary text-primary-foreground font-semibold shadow-md">Dashboard</Badge>
                  <Badge variant="outline" className="font-medium border-primary/40">
                    Plan: {user.subscription}
                  </Badge>
                  <Badge variant="outline" className="font-medium border-primary/40">
                    30j: {user.workoutsCount} séances
                  </Badge>
                </div>
                <div>
                  <h1 className="text-3xl md:text-5xl font-bold text-balance mb-3 leading-tight">
                    Salut {user.firstName}, ton cockpit est prêt.
                  </h1>
                  <p className="text-muted-foreground text-pretty leading-relaxed text-lg">
                    Suivi temps réel, IA et objectifs dans une vue épurée. Continue à logger tes sets pour affiner les
                    1RM et les recommandations.
                  </p>
                </div>
                <div className="flex flex-wrap gap-3 pt-2">
                  <Button className="gap-2 shadow-lg hover:shadow-xl transition-all hover:scale-105">
                    <Dumbbell className="h-4 w-4" />
                    Nouvelle séance
                  </Button>
                  <Button
                    variant="outline"
                    className="gap-2 border-2 hover:bg-accent/10 hover:border-accent transition-all bg-transparent"
                  >
                    <Target className="h-4 w-4" />
                    Objectifs
                  </Button>
                  <Button
                    variant="outline"
                    className="gap-2 border-2 hover:bg-primary/10 hover:border-primary transition-all bg-transparent"
                  >
                    <Activity className="h-4 w-4" />
                    Chat IA
                  </Button>
                </div>
              </div>

              <div className="md:col-span-2">
                <Card className="h-full bg-card/95 backdrop-blur-sm border-2 border-primary/30 shadow-lg">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardDescription className="font-semibold text-base">En un coup d'œil</CardDescription>
                      <Badge className="bg-accent text-accent-foreground font-semibold shadow-md">Live</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-4">
                      <div className="font-bold text-lg mb-1">Top 1RM: Bench Press</div>
                      <div className="text-sm text-muted-foreground">
                        Actuel <span className="font-semibold text-foreground">95 kg</span> · Prévu 7j{" "}
                        <span className="font-semibold text-primary">98 kg</span>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-border">
                      <div className="text-sm text-muted-foreground mb-2 font-medium">Streak · Points</div>
                      <div className="flex items-baseline gap-2">
                        <Flame className="h-6 w-6 text-destructive" />
                        <span className="font-bold text-2xl">{user.streak} j</span>
                        <span className="text-muted-foreground">—</span>
                        <Zap className="h-5 w-5 text-primary" />
                        <span className="font-bold text-xl">{user.points.toLocaleString()} pts</span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">Niveau {user.level}</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {kpis.map((kpi, i) => (
            <Card
              key={i}
              className="hover:shadow-xl transition-all hover:border-primary/50 hover:-translate-y-1 duration-300 border-2"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-sm font-semibold text-muted-foreground">{kpi.label}</div>
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${kpi.color}`}>
                    <kpi.icon className="h-5 w-5 text-white" />
                  </div>
                </div>
                <div className="text-3xl font-bold mb-1">{kpi.value}</div>
                <div className="text-sm text-muted-foreground font-medium">{kpi.sub}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-5 gap-6 mb-6">
          <Card className="md:col-span-2 border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Charge & récupération
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Workouts 7j</span>
                <span className="font-bold text-lg">{user.workoutsCount}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Volume (reps)</span>
                <span className="font-bold text-lg">3,240</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Volume semaine -1</span>
                <span className="text-sm font-semibold">2,890</span>
              </div>
              <div className="pt-3 mt-3 border-t-2 border-border">
                <div className="bg-gradient-to-r from-accent/20 to-accent/10 text-accent-foreground rounded-lg p-4 text-sm leading-relaxed font-medium border-l-4 border-accent">
                  Charge maîtrisée. Reste en RPE 7-8 et dors suffisamment.
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-3 border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Recommandations IA
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-muted/80 to-muted/40 hover:from-muted hover:to-muted/60 transition-all cursor-pointer border-l-4 border-primary">
                  <div className="text-sm text-muted-foreground font-medium">Travaille davantage</div>
                  <div className="font-bold">Épaules · 28 sets/30j</div>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-muted/80 to-muted/40 hover:from-muted hover:to-muted/60 transition-all cursor-pointer border-l-4 border-secondary">
                  <div className="text-sm text-muted-foreground font-medium">Travaille davantage</div>
                  <div className="font-bold">Triceps · 22 sets/30j</div>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-muted/80 to-muted/40 hover:from-muted hover:to-muted/60 transition-all cursor-pointer border-l-4 border-accent">
                  <div className="text-sm text-muted-foreground font-medium">Travaille davantage</div>
                  <div className="font-bold">Mollets · 18 sets/30j</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-5 gap-6 mb-6">
          <Card className="md:col-span-3 border-2 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  Dernières séances
                </CardTitle>
                <Button variant="ghost" size="sm" className="gap-1 hover:text-primary font-semibold">
                  Voir tout
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {recentWorkouts.map((workout, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg hover:bg-gradient-to-r hover:from-muted/80 hover:to-muted/40 transition-all cursor-pointer group border border-transparent hover:border-primary/30"
                  >
                    <div>
                      <div className="font-bold group-hover:text-primary transition-colors">{workout.title}</div>
                      <div className="text-sm text-muted-foreground font-medium">{workout.date}</div>
                    </div>
                    <div className="text-right text-sm">
                      <div className="font-semibold">Sets {workout.sets}</div>
                      <div className="text-muted-foreground">Volume {workout.volume.toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Objectifs & badges
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm text-muted-foreground mb-3 font-semibold">Objectifs actifs</div>
                <div className="space-y-4">
                  {goals.map((goal, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-semibold">{goal.title}</span>
                        <span className="text-muted-foreground font-bold">{goal.progress}%</span>
                      </div>
                      <Progress value={goal.progress} className="h-3 shadow-sm" />
                    </div>
                  ))}
                </div>
              </div>
              <div className="pt-4 border-t-2 border-border">
                <div className="text-sm text-muted-foreground mb-3 font-semibold">Badges récents</div>
                <div className="flex flex-wrap gap-2">
                  <Badge className="gap-1 bg-gradient-to-r from-accent to-accent/80 text-accent-foreground shadow-md font-semibold px-3 py-1">
                    <Award className="h-4 w-4" />
                    Centurion
                  </Badge>
                  <Badge className="gap-1 bg-gradient-to-r from-secondary to-secondary/80 text-secondary-foreground shadow-md font-semibold px-3 py-1">
                    <Award className="h-4 w-4" />
                    Warrior
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Tendance 1RM
              </CardTitle>
              <CardDescription className="font-medium">Progression estimée sur 7 jours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {trends.map((trend, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg hover:bg-gradient-to-r hover:from-muted/80 hover:to-muted/40 transition-all border border-transparent hover:border-primary/30"
                  >
                    <div className="font-bold text-lg">{trend.exercise}</div>
                    <div className="text-sm text-right">
                      <span className="text-muted-foreground font-medium">Actuel {trend.current} kg</span>
                      <span className="mx-2">·</span>
                      <span className="text-primary font-bold">Prévu {trend.predicted} kg</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 shadow-lg">
            <CardHeader>
              <CardTitle>Focus musculaire</CardTitle>
              <CardDescription className="font-medium">Équilibre des groupes musculaires</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm text-muted-foreground mb-3 font-semibold">Points forts</div>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-md font-semibold px-3 py-1.5">
                    Pectoraux · 48 sets
                  </Badge>
                  <Badge className="bg-gradient-to-r from-secondary to-secondary/80 text-secondary-foreground shadow-md font-semibold px-3 py-1.5">
                    Quadriceps · 42 sets
                  </Badge>
                  <Badge className="bg-gradient-to-r from-accent to-accent/80 text-accent-foreground shadow-md font-semibold px-3 py-1.5">
                    Dos · 38 sets
                  </Badge>
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-3 font-semibold">Points faibles</div>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="border-2 font-semibold px-3 py-1.5">
                    Épaules · 22 sets
                  </Badge>
                  <Badge variant="outline" className="border-2 font-semibold px-3 py-1.5">
                    Triceps · 20 sets
                  </Badge>
                  <Badge variant="outline" className="border-2 font-semibold px-3 py-1.5">
                    Mollets · 15 sets
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
